<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'D834CXI1EcqcmpmX7AWhXILrT';
$config['twitter_consumer_secret']		= 'sfJA4uSG0CiG7Qw9QhSJnbB0UwRVUEPEiheWyXVIRSSjKAgl9r';

$config['twitter_access_token']			= '766181497636356096-g6yzVr7Q7w6nXvhYvQznol3oj2SZT5t'; // Optional
$config['twitter_access_secret']		= 'KbvjHWihJAB9LIHUIax2bDOnhXIlkWp0hBAX74hUfjrs3'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */