<?php
/**
 * linkedin library configuration
 */
// this app from user pampimofficial@gmail.com
/*$config = array(
  'appKey'    => '75lu0ov8y0kc06',
  'appSecret' => 'Y2xUeKdKK4tr3zdG',
  'callbackUrl'      => site_url().'/social/linkedin_success/' // Default callback application path
);*/
// this app is created on user udiraiter2@gmail.com
$config = array(
  'appKey'    => '81pygv0czv3dl9',
  'appSecret' => 'Ava0rfxbADp0COpV',
  'callbackUrl'      => site_url().'/Linkedin_data/linkedin_success' // Default callback application path
);
?>