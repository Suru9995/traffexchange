
<!-- Jquery Core Js -->

    <script src="<?php echo base_url('assets/admin/plugins/jquery/jquery.min.js'); ?>" type="text/javascript"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url('assets/admin/plugins/bootstrap/js/bootstrap.js'); ?>" type="text/javascript"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/bootstrap-select/js/bootstrap-select.js'); ?>" type="text/javascript"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/jquery-slimscroll/jquery.slimscroll.js'); ?>" type="text/javascript"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/node-waves/waves.js'); ?>" type="text/javascript"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/jquery-countto/jquery.countTo.js'); ?>" type="text/javascript"></script>

    <!-- Morris Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/raphael/raphael.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/plugins/morrisjs/morris.js'); ?>" type="text/javascript"></script>

    <!-- ChartJs -->
    <script src="<?php echo base_url('assets/admin/plugins/chartjs/Chart.bundle.js'); ?>" type="text/javascript"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.resize.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.pie.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.categories.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/plugins/flot-charts/jquery.flot.time.js'); ?>" type="text/javascript"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="<?php echo base_url('assets/admin/plugins/jquery-sparkline/jquery.sparkline.js'); ?>" type="text/javascript"></script>

    <!-- Custom Js -->
    <script src="<?php echo base_url('assets/admin/js/admin.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/admin/js/pages/index.js'); ?>" type="text/javascript"></script>

    <!-- Demo Js -->
    <script src="<?php echo base_url('assets/admin/js/demo.js'); ?>" type="text/javascript"></script>
   
   <script src="<?php echo base_url('assets/js/Chart.min.js'); ?>"></script>
    
</body>

</html>
