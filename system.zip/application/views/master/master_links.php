
<!-- Css Links -->

<link href="<?php echo base_url('assets/image/favicon.png'); ?>" rel="icon">
<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/header.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/contact_us.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/features.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/login.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/footer.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/owl.carousel.min.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/owl.theme.default.min.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/animate.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/info.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/dev.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/user_master.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url('assets/css/header_user.css');?>" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/login_page.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/user_social.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/rain.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/how_it_works.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/animations.css" type="text/css" rel="stylesheet">


<!-- Js Links -->

<script src="<?php echo base_url('assets/js/jquery-3.2.1.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/owl.carousel.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/home_page.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/user_head.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/Chart.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/css3-animate-it.js'); ?>"></script>



