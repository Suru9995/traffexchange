
<footer>
	<div class="footer">
    	<div class="container">
        	<div class="row no-gutters pb-3" style="border-bottom:1px solid grey;">

                     	<div class="col-lg-12 mt-4">
                        <table class="tbl_extra" width="60%" align="center">
                        	
                            <tr>
                            
                                <td><a href="#"><img src="<?php echo base_url('assets/image/facebook.png'); ?>" width="40"/></a></td>
                                <td><a href="#"><img src="<?php echo base_url('assets/image/twitter.png'); ?>" width="40"/></a></td>
                                <td><a href="#"><img src="<?php echo base_url('assets/image/instagram.png'); ?>" width="40"/></a></td>
                                <td><a href="#"><img src="<?php echo base_url('assets/image/google-plus.png'); ?>" width="40"/></a></td>
                            </tr>
                            
                           
                        </table>
<!--<hr color="#aaa">-->
                         <table class="tbl_extra mt-4 text-center" width="60%" align="center">
                        	
                            <tr>
                            
                                <td style="border-right:2px solid #fff;"><a href="<?php echo site_url('contact-us'); ?>" class="text-white lead"><b>Contact Us</b></a></td>
                                <td style="border-right:2px solid #fff;"><a href="<?php echo site_url('How-it-works'); ?>" class="text-white lead"><b>How it works?</b></a></td>
                                <td style="border-right:2px solid #fff;"><a href="<?php echo site_url('about-us'); ?>" class="text-white lead"><b>About Us</b></a></td>
                                <td><a href="<?php echo site_url('privacy-policy'); ?>" class="text-white lead"><b>Privacy Policy</b></a></td>
                               
                            </tr>
                            
                           
                        </table>
                        
                        </div>

            
            
            	
                
            </div>
            
            <div class="row no-gutters text-center pt-3 pb-3">
            <div class="col-lg-12">
            	<h5>Copyright &copy; 2018 TraffExchange - All Rights Reserved.</h5>
            </div>
            </div>
        </div>
    </div>
</footer>

