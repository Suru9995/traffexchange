<head>
<?php $this->load->view('master/master_links'); ?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Youtube Likes</title>
</head>

<body>
<?php $this->load->view('master/user_master'); ?>

	

    <h1>Youtube Likes</h1>
   
	
<script src="https://apis.google.com/js/platform.js"></script>
<div class="g-ytsubscribe" data-channelid="UC_x5XG1OV2P6uZZ5FSM9Ttw" data-layout="full" data-count="hidden"></div>
    
</body>
</html>