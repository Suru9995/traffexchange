<!doctype html>
<html>
<head>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>How to get likes , shares on facebook</title>

<?php $this->load->view('master/master_links');
	$this->load->view('master_logo_menu');
 ?>



</head>
<body>

<?php
	$this->load->view('master/scrolltotop');
?>

<div class="how_fb how_main">
	<div class="container">
        <div class="contact_text fb_text">
                	<h1>How to grow your<br> facebook account?</h1>
            </div>
            
    </div>
</div>

<div class="abt_help">
	<div class="container">
    	
        <div class="row no-gutters pt-5 pb-5">
        
        
        	<div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
            	<h2>How to get more likes on facebook ?</h2><br>
                <p class="lead text-justify">&emsp;&emsp; To getting more likes in facebook you want to reach more population in facebook but the problem is facebook allows only 5000 friend in your friend list. The TraffExchange allows you to reach more population getting more socialize your facebook profile as well as page. TraffExchange also allows to socialize your profile in cross social media like Twitter. In short you can exchange likes,views,Tweets,Retweets,hits using TraffExchange. so, it is eusy to get likes on facebook using our site. You can add your Facebook page for like and other TraffExchange user can view your page and like your Page. Also, other user can share your page.</p>
            </div>
            
            
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
            	<h2>How to get more shares on facebook ?</h2><br>
                <p class="lead text-justify">&emsp;&emsp; User share his business link, website link, Youtube video link in facebook. While user share this in facebook all user friend can view that. so, if other user share this links on their fb account then that user all friends can view your links and this way you can grow in facebook. In, short other user can share your profile so, become famous in facebook. But there is an problem with share <strong>Why other user share your profile ?</strong> TraffExchange give you answer this Question. <strong>Answer is Below.</strong></p>
            </div>
        
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
            	<h2>How TraffExchane help to grow on facebook ?</h1><br>
                <p class="lead text-justify">&emsp;&emsp; <strong>TraffExchange</strong> is a Like and View sharing programm that help user to grow in social world. This is work on credits (coins) basis user get <strong><big>50</big> coins</strong> on successfully Register. after that user add <strong>facebook page and links</strong> in our site using <strong>URL</strong>. other user can view your <strong>facebook profile</strong> and page links you add. if other user like your facebook page through our website user will get points for that and your point deduct as well as if you like or share other user facebook page or links you get points and page owner point deduct. In short <strong>more credits ,means more chance to grow on social media through our website.</strong></p>
            </div>
        </div>
        
    </div>
</div>

<!-- <div class="abt_help">
	<div class="container">
    	
        <div class="row no-gutters pt-5 pb-5">
        	<div class="col-lg-12 col-md-12 col-sm-12 col-12">
            	<h1 align="center">Also Visit</h1><br>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 pl-5">
                <p class="lead"><a href="<?php echo site_url('twitter');?>">How to grow your Twitter account?</a></p>
                <p class="lead"><a href="<?php echo site_url('youtube');?>">How to grow your Youtube channel?</a></p>
                <p class="lead"><a href="<?php echo site_url('website');?>">How to get more Website traffic?</a></p>
            </div>
        </div>
        
    </div>
</div> -->

<div class="container">
	<h2 class="text-center mb-4">Also Read Related Articles</h2>
    <hr style="border:1px solid #394C60; margin-bottom:30px;">
    
    <div class="row mb-5">
    
    	<div class="col-lg-4 col-md-4 col-sm-12 col-12">
        	<div class="art">
            <a href="<?php echo site_url('twitter');?>">
            	<div class="img_art">
                	<img src="<?php echo base_url(); ?>/assets/image/tw_info.png" height="100%" width="100%" />
                </div>
                
                <div class="text_art">
                	<h3 class="text-center pt-4">How to grow your twitter account ?</h3>
                </div>
            </a>
            </div>
        </div>

       
       <div class="col-lg-4 col-md-4 col-sm-12 col-12">
       		<div class="art">
        		<a href="<?php echo site_url('youtube');?>">
            	<div class="img_art">
                	<img src="<?php echo base_url(); ?>/assets/image/yt_info.png" height="100%" width="100%" />
                </div>
                <div class="text_art">
                	<h3 class="text-center pt-4">How to grow your youtube channel ?</h3>
                </div>
                </a>
            </div>
        </div>
        
        
        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
        	<div class="art">
            	<a href="<?php echo site_url('website');?>">
            	<div class="img_art">
                	<img src="<?php echo base_url(); ?>/assets/image/wt_art.png" height="100%" width="100%" />
                </div>
                <div class="text_art">
                	<h3 class="text-center pt-4">How to grow your website ?</h3>
                </div>
                </a>
            </div>
        </div>
        
       
    </div>
</div>



<?php
	$this->load->view('master/footer_master');
?>
</body>
</html>