<head>
<?php $this->load->view('master/master_links'); ?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Free Credits</title>
</head>

<body>
<?php $this->load->view('master/user_master'); ?>

	

    <h1>Free Credits</h1>
   

    
</body>
</html>